<?php
class Model {
    public $response;
    public $login_name;
    public $password;
    public function __construct($login_name,$password) {
        $this->login_name = $login_name;
        $this->password = $password;
        $this->response = 0;
    }  
    public function search($db_servername,$db_username,$db_password,$db_name,$db_port){
      $conn=new mysqli($db_servername,$db_username,$db_password,$db_name,$db_port);
         if ( $conn->connect_error )
         {
              echo  die("Could not connect to database </body></html>" );
         }
         else
         {
              $squery = "SELECT * FROM tbl_accounts";
              $result = $conn->query($squery);
              while($row = mysqli_fetch_row($result))
              {
               if ($this->login_name == $row[2])
               {
                  if(sha1($this->password) == $row[3])
                  {
                    $this->response =1;
                    $conn->close();
                  }
                  else
                  {
                    $this->response = 2;
                  }
               }

              }
              if($this->response == 0)
              {
                $this->response = 3;
              }
              $conn->close();
         }
    }
}  
?>