<html>
<head>
<style type="text/css">
  table,td{
  border: 1px solid black;
    border-collapse: collapse;
  }
table{
  width: 100%;
}

</style>  


</head>
<body>
<form action = <?php echo $_SERVER["PHP_SELF"]; ?> method="post">
  <button name="log_out" type="submit" value="log_out">Log out</button>
</form>
<nav>
  <button onclick="{location.href='calendar.php'}">My Calendar</button>
  <button onclick="{location.href='form.php'}">Form Input</button>
  <button onclick="{location.href='view_users.php'}">Admin</button>

 </nav>
<h1>Add New User</h1>
<?php
   session_start();
  if(empty($_SESSION["login_name"]))
  {
    header("Location:login.php");
  }
  else
  {
    echo 'Welcome     '.$_SESSION["login_name"];
    echo '<br>';
    $login_name = $_SESSION["login_name"];
  }
   include_once 'model_users.php';
   include_once 'database_HW8F16.php';
   include_once 'controller_user.php';
   $login_flag = '';



   class View
   {
    public $model;
    public $controller;
    public $text;
    public function __construct(Controller $controller,Model $model)
    {
      $this->model = $model;
      $this->controller = $controller;
      $this->text = 'view ok';
    }

    public function build_list($login_flag)
    {
      $list = $this->model->get_list();
      /*echo "<tr><th>83</th><td>Rain Yuki</td><td>Rain 1995</td><td></td><td>
      <input type = 'submit' value = 'edit' name='Add'>
      <input type = 'submit' value = 'delete' name='Add'>
      </td>
      </tr>";*/
      foreach ($list as $element) 
      {
        if($login_flag != $element[2])
        {
            echo "<tr>";
            echo "<th>";
            echo $element[0];
            echo "</th>";
            echo "<td>";
            echo $element[1];
            echo "</td>";
            echo "<td>";
            echo $element[2];
            echo "</td>";
            echo "<td>";
            echo "";
            echo "</td>";
            echo "<td>";
            echo "<button name='edit' type='submit' value=".$element[2].">edit</button>";
            echo "<button name='delete' type='submit' value=".$element[2].">delete</button>";
            echo "</td>";
            echo "</tr>";
        }
        else
        {
            echo "<tr>";
            echo "<th>";
            echo $element[0];
            echo "</th>";
            echo "<td>";
            echo "<input type='text' name='new_name'>";
            echo "</td>";
            echo "<td>";
            echo "<input type='text' name='new_login'>";
            echo "</td>";
            echo "<td>";
            echo "<input type='text' name='new_password'>";
            echo "</td>";
            echo "<td>";
            echo "<button name='update' type='submit' value=".$element[2].">update</button>";
            echo "<button name='cancel' type='submit' value=".$element[2].">cancel</button>";
            echo "</td>";
            echo "</tr>";
        }
      }
    }

   }
     




     if(isset($model) == NULL)
     {
      $model = new Model($db_servername,$db_username,$db_password,$db_name,$db_port);
      $controller = new Controller($model);
      $view = new View($controller,$model);
     }


  

   
   
   $New_nameerr = '';
   if($_SERVER["REQUEST_METHOD"] == "POST")
   {
     if($_POST["Add"] == 'Add')
     {
    $controller->add($_POST['New_name'],$_POST['New_login'],$_POST['New_password']);
    
     }
     if($_POST["edit"] != '')
     {
      $login_flag = $_POST["edit"];
     }
     if($_POST["delete"] != '')
     {
      $controller->delete($_POST["delete"]);
     }
     if($_POST["update"] != '')
     {
      $controller->update($_POST["update"],$_POST["new_name"],$_POST["new_login"],$_POST["new_password"]);
     }
     if($_POST["log_out"] == "log_out")
      {
        session_destroy();
        header("Location:logout.php");
      }
   }
?>   
  <form action = <?php echo $_SERVER["PHP_SELF"]; ?> method="post">
  	Name: &nbsp;&nbsp;
    <input type="text" name="New_name">
    <span class="error"><?php echo $New_nameerr;  ?></span>
    <br>
    login: &nbsp;&nbsp;
    <input type="text" name="New_login">
    <br>
    password: &nbsp;&nbsp;
    <input type="text" name="New_password">
    <br>
     <p><input type = "submit" value = "Add" name="Add"></p>
  </form>

  <form action = <?php echo $_SERVER["PHP_SELF"]; ?> method="post">
    <table>
      <tr>
      <th>ID</th>
      <td>Name</td>
      <td>Login</td>
      <td>New Password</td>
      <td>Action</td>
      </tr>
      <?php
      $view->build_list($login_flag);  
      ?>
    </table>
  </form>



</body>
</html>