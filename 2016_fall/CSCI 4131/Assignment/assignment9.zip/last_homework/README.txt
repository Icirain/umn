login:JJones
password:JJ456
In the admin page. The edit function and add function will firstly check whether login_name which will be upadated of added exists. If so. the erro warning will be displayed under the hello message of the page. Besides, if the edit function activated and the input new login_name, password and name are empty, the error message will be displayed in the same place.

x500:zuoxx067
ID:5323641
