
<?php
  include_once 'model_uses.php';
			class Controller 
			{
			    public $model;
                public $text;
			    public function __construct(Model $model) 
			    {
			        $this->model = $model;
			        $this->text = 'Controller ok';
			    }
			    public function add($name,$login,$password)
			    {
			    	$error = 0;
			    	if(empty($name))
			    	{
			    		$error = 1;
			    		echo 'Please enter a valid name';
			    		echo '<br>';
			    	}
			    	if(empty($login))
			    	{
			    		$error = 1;
			    		echo 'Please enter a valid name';
			    		echo '<br>';

			    	}
			    	if(empty($password))
			    	{
			    		$error =1;
			    		echo 'Please enter a valid name';
			    		echo '<br>';
			    		
			    	}
			    	if($error == 0)
			    	{
			    		$this->model->insert($name,$login,$password);
			    	}
			    }

			    public function delete($login)
			    {
			    	$this->model->delete($login);
			    }

			    public function update($ori_login,$name,$login,$password)
			    {
			    	$this->model->update($ori_login,$name,$login,$password);
			    }



			
			}



  ?>