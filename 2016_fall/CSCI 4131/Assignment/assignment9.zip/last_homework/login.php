<!DOCTYPE html>
<html>
   <head>
      <meta charset = "utf-8">
      <title>Login Page</title>
   </head>
   <body>
   <?php include_once 'controller_login.php'; ?>
      <h1>Please enter you login name and password. Both of them are case sensitive</h1>
      <form method = "post" action = <?php echo $_SERVER["PHP_SELF"]; ?>  >
         Login name: &nbsp;&nbsp;
         <input type="text" name="login">
         <span class="error"><?php echo $loginerr;  ?></span>
         <br>
         password: &nbsp;&nbsp;
         <input type="text" name="password">
         <span class="error"><?php echo $passworderr;  ?></span>
         <br>
         <p><input type = "submit" value = "submit" name="submit"></p>
      </form>
   </body>
</html>
