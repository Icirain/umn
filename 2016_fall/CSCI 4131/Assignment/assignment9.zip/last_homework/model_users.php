<?php
class Model
{
	public $text;
	public $db_servername;
	public $db_username;
	public $db_password;
	public $db_name;
	public $db_port;
	public function __construct($db_servername,$db_username,$db_password,$db_name,$db_port)
	{
       $this->text = 'model ok';
       $this->db_servername = $db_servername;
       $this->db_username = $db_username;
       $this->db_password = $db_password;
       $this->db_name =$db_name;
       $this->db_port = $db_port;
	}
	public function get_list()
	{
        $conn=new mysqli($this->db_servername,$this->db_username,$this->db_password,$this->db_name,$this->db_port);
        if ( $conn->connect_error )
         {
              echo  die("Could not connect to database </body></html>" );
         }
        else
         {
         	$squery = "SELECT * FROM tbl_accounts";
            $result = $conn->query($squery);
            $list = array();
            while($row = mysqli_fetch_row($result))
            {
            	array_push($list,$row);
            }
            //print_r($list);

            
         }
       return $list;
     

	}
	public function insert($name,$login,$password)

    {
      $conn=new mysqli($this->db_servername,$this->db_username,$this->db_password,$this->db_name,$this->db_port);
        if (mysqli_connect_errno())
        {
        echo 'Failed to connect to MySQL:' . mysqli_connect_error();
        }
        $error = $this->check_exist($login);
        
      if($error == 1)
      {
      	echo 'The login name is duplicated';
      }
      else
      {
	      $name = mysqli_real_escape_string($conn,$name);
	      $login = mysqli_real_escape_string($conn,$login);
	      mysqli_query($conn,"INSERT INTO tbl_accounts (acc_name, acc_login, acc_password) VALUES ('$name', '$login', '". sha1($password)."')");
	      mysqli_close($conn);
	      //header("Location:test.php");
	      echo 'already insert';
      }

    }


      public function check_exist($login)
      {
      	$conn=new mysqli($this->db_servername,$this->db_username,$this->db_password,$this->db_name,$this->db_port);
      	if (mysqli_connect_errno())
        {
        echo 'Failed to connect to MySQL:' . mysqli_connect_error();
        }
        $error = 0;
        $squery = "SELECT * FROM tbl_accounts";
        $result = $conn->query($squery);
        while($row = mysqli_fetch_row($result))
        {
        	if($row[2] == $login)
        	$error = 1;
        }
        mysqli_close($conn);
        return $error;
      }
      


      public function delete($login)
      {
        $conn=new mysqli($this->db_servername,$this->db_username,$this->db_password,$this->db_name,$this->db_port);
        if (mysqli_connect_errno())
        {
        echo 'Failed to connect to MySQL:' . mysqli_connect_error();
        }
        $query = "DELETE FROM tbl_accounts WHERE acc_login = '$login'";
        //mysqli_query($conn,$query);
        $status = $conn->query($query);
        mysqli_close($conn);
        //echo $status;

      }
      public function update($ori_login,$name,$login,$password)
      {
        $conn=new mysqli($this->db_servername,$this->db_username,$this->db_password,$this->db_name,$this->db_port);
        $errro_login = $this->check_exist($login);
        if($errro_login == 1)
        {
          echo 'New login_name already exists';
          return;
        }
        if ($name == '' Or $login == '' Or $password == '')
        {
          echo 'New password , new login or new name can not be empty';
          return;
        }
        if (mysqli_connect_errno())
        {
        echo 'Failed to connect to MySQL:' . mysqli_connect_error();
        }
        $error = $this->check_exist($ori_login);
        $password = sha1($password);
        if($error == 0)
        {
          echo "This account doesn't exist";
        }
        else
        {
          $query = "UPDATE tbl_accounts SET acc_name = '$name' , acc_login = '$login', acc_password = '$password' WHERE acc_login = '$ori_login'";
          $status = $conn->query($query);
          mysqli_close($conn);
        }
      }

}

?>