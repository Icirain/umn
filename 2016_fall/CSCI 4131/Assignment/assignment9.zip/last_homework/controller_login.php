   <?php
   include_once 'database_HW8F16.php';
   include_once 'model_login.php';
   $passworderr = $loginerr = "";
   $Condition = 1;
   $password = $_POST["password"];
   $login_name = $_POST["login"];
   if($_SERVER["REQUEST_METHOD"] == "POST")
   {
      if(empty($_POST["login"]))
      {
         $loginerr = "Please enter a valid login value";
         $Condition = 0;
      }
      if(empty($_POST["password"]))
      {
         $passworderr = "Please enter a valid password value";
         $Condition = 0;
      }
      if($Condition == 1)
      {
         $model = new Model($login_name,$password);
         $model->search($db_servername,$db_username,$db_password,$db_name,$db_port);
         switch($model->response)
         {
          case 1:
              session_start();
              $_SESSION["login_name"] = $login_name;
              header("Location:calendar.php");
              break;
          case 2:
              $passworderr = 'Your password is not correct';
              break;
          case 3:
              $loginerr = "This account does't exist";
              break;
          default:
              $loginerr = "Something Wrong";
         }
         
      }
   }
   ?>