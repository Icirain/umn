<html>
<body>

<h1>Welcome to my home page!</h1>
<p>Some text.</p>
<p>Some more text.</p>
<?php
   include_once 'model_account.php';
   include_once 'database_HW8F16.php';
   include_once 'controller_user.php';
   $model = new Model($db_servername,$db_username,$db_password,$db_name,$db_port);
   //echo $model->get_list();
   if($_SERVER["REQUEST_METHOD"] == "POST")
   {
   	if($_POST["insert"] == "insert")
      {
        $model->update("Rain",'Rain','Rain','1234');
      }
   }
   echo $model->check_exist('Rain19');
   $list = $model->get_list();
   echo $list[0][2];
    print_r($list);



  ?>
  <form action = <?php echo $_SERVER["PHP_SELF"]; ?> method="post">
  <button type = "submit" value = "insert" name = "insert">insert</button>
  	
  </form>
</body>
</html>