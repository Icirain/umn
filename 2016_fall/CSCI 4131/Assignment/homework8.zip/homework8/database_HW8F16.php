<?php
      $db_servername = 'egon.cs.umn.edu';
      $db_port = 3307;
      $db_name = 'C4131F16U131';  //Note xxx is a number, you can find it on moodle
      $db_username = 'C4131F16U131';
      $db_password = 19383;  // This should be on moodle as well.
?>
